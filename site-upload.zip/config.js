window.FLUTTERWAVE_PUBLIC_KEY = 'FLWPUBK_TEST-f9ddc058e9bf5430d7663d97437c9b55-X';
// Optional: set Paystack public key if you plan to test Paystack
// window.PAYSTACK_PUBLIC_KEY = 'pk_test_xxxxxxxxxxxxxxxxxxxxxxxxx';
window.AMAZON_ASSOCIATE_TAG = 'xpertonboaruk-21-20';
